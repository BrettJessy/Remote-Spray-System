package com.orchard.spray;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;
import java.io.PrintStream;


public class ClientThread implements Runnable {
    //定义套接字
    public static Socket s;
    // 定义向UI线程发送消息的Handler对象。
    private Handler myHandler;
    // 定义接收UI线程的消息的Handler对象.
    public Handler recHandler;
    // 定义给UI线程发送灯的状态的Handler对象.
    public Handler sendHandler;
    // 该线程所处理的Socket所对用的流对象
    private PrintStream output;
    //数据接收线程
    public static Thread recvThread = null;


    public ClientThread(Handler handler) {
        super();
        this.myHandler = handler;
    }

    @Override
    public void run() {

        // 为当前线程初始化Looper
        Looper.prepare();
        recHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);
                if (msg.what == 2) {
                    try {
                        s = new Socket(MainActivity.IP, 4720);//创建socket连接
                        myHandler.sendEmptyMessage(0);//连接成功向界面线程发送0
                    } catch (IOException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                        myHandler.sendEmptyMessage(1);//连接失败发送1
                    }
                }
                if (msg.what == 3)//喷雾按钮按下
                {
                    try {//获取输出流，发送喷雾参数
                        output = new PrintStream(s.getOutputStream(), true, "utf-8");
                        output.print("r" + ",");
                        output.print(MainActivity.Auto + ",");
                        output.print(MainActivity.checkL + ",");
                        output.print(MainActivity.checkR + ",");
                        output.print(MainActivity.V + ",");
                        output.print(MainActivity.D + "\n");//以\n为结束标志
                        output.flush();//数据刷新
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (msg.what == 4)//停止按钮按下
                {
                    try {//发送字符串s
                        output = new PrintStream(s.getOutputStream(), true, "utf-8");
                        output.print("s" + "," + "\n");
                        output.flush();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (msg.what == 5)//退出按钮按下
                {
                    try {//发送字符串e
                        output = new PrintStream(s.getOutputStream(), true, "utf-8");
                        output.print("e" + "," + "\n");
                        output.flush();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                //新建数据接收线程
                 if(recvThread==null){
                recvThread = new Thread(receive);
                recvThread.start();}
            }
        };
        Looper.loop();
    }

    /*数据接收线程，接收来自控制器传来的灯的状态*/
    private Runnable receive = new Runnable() {
        public void   run()
        {
            Looper.prepare();
            sendHandler=new Handler() {
                @Override
                public void handleMessage(Message msg) {
                    super.handleMessage(msg);
                    if (msg.what==6) {
                        try {
                            //输入流，获取服务器端传来的数据
                            DataInputStream in = new DataInputStream(s.getInputStream());
                            byte[] bytes = new byte[8]; // 一次读取8个byte
                            int btlength=in.read(bytes);//字节数组的长度
                                // 每当读到来自服务器的数据之后，发送消息通知程序界面显示该数
                            if(btlength==8) {
                                //将灯的状态放入字节数组传给界面线程刷新
                                Message msg3 = Message.obtain();
                                msg3.what = 0x123;//更新标识
                                Bundle b = new Bundle();
                                b.putByteArray("NOZZLE",bytes);
                                msg3.setData(b);
                                myHandler.sendMessage(msg3);
                                sendHandler.sendEmptyMessage(6);//自身不断循环
                            }
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            };
            Looper.loop();
                }
    };


}
