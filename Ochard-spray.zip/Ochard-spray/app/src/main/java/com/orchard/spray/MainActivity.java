package com.orchard.spray;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.RadioButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.CheckBox;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.annotation.SuppressLint;
import static com.orchard.spray.R.id.autoSpray;
import android.os.Handler;
import android.os.Message;
import java.io.IOException;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ImageButton start;
    ImageButton out;
    ImageButton connect;
    RadioButton autospray;
    CheckBox sprayl;
    CheckBox sprayr;
    ImageView image1;
    ImageView image2;
    ImageView image3;
    ImageView image4;
    ImageView image5;
    ImageView image6;
    ImageView image7;
    ImageView image8;
    EditText speed;
    EditText distance;
    EditText ip;
    EditText port;
    boolean  RUN = false;//线程启停
    boolean  flag = false;//单选按钮的选中与否
    public static boolean Auto=true;//自动状态
    public static boolean checkL=true;//左侧喷雾
    public static boolean checkR=true;//右侧喷雾}
    public static String V;
    public static String D;
    public static String IP;
    public static String PORT;
    boolean OUT = false;
    ClientThread sendThread;
    public byte[] NOZZLE=new byte[8];//灯的状态


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setBtnAffairs(); }

    @SuppressLint("ClickableViewAccessibility")
    public void setBtnAffairs() {

        start=(ImageButton)findViewById(R.id.start);//喷雾按钮
        out=(ImageButton)findViewById(R.id.out);//退出按钮
        connect=(ImageButton)findViewById(R.id.connect);//连接按钮
        autospray=(RadioButton)findViewById(autoSpray);//自动手动
        sprayl=(CheckBox)findViewById(R.id.sprayL);//左侧喷雾
        sprayr=(CheckBox)findViewById(R.id.sprayR);//右侧喷雾
        image1=(ImageView)findViewById(R.id.image1);
        image2=(ImageView)findViewById(R.id.image2);
        image3=(ImageView)findViewById(R.id.image3);
        image4=(ImageView)findViewById(R.id.image4);
        image5=(ImageView)findViewById(R.id.image5);
        image6=(ImageView)findViewById(R.id.image6);
        image7=(ImageView)findViewById(R.id.image7);
        image8=(ImageView)findViewById(R.id.image8);
        speed=(EditText)findViewById(R.id.speed);
        speed.clearFocus();//失去焦点
        distance=(EditText)findViewById(R.id.distance);
        distance.clearFocus();//失去焦点
        ip=(EditText)findViewById(R.id.IP);
        ip.clearFocus();//失去焦点
        port=(EditText)findViewById(R.id.port);
        port.clearFocus();//失去焦点
        speed.setText("1");//速度初值
        distance.setText("1");//距离初值
        ip.setText("10.0.142.199");//ip地址初值
        port.setText("4720");//端口号初值
        autospray.setChecked(true);//自动喷雾按钮默认选中
        sprayl.setChecked(true);//左侧喷雾默认选中
        sprayr.setChecked(true);//右侧喷雾默认选中
        start.setEnabled(false);//喷雾按钮初始状态
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE |
                WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);//默认不弹出软件键盘
        //线程启动，负责建立socket连接，发送喷雾参数
        sendThread = new ClientThread(myHandler);
        new Thread(sendThread).start();

        connect.setOnClickListener(new Button.OnClickListener()
        { @Override
        public void onClick(View v) {//连接按钮监听
            // Connect=true;
            IP = ip.getText().toString();//获取IP地址
            PORT = port.getText().toString();//获取端口号
            sendThread.recHandler.sendEmptyMessage(2);//连接标识
        }
        });
        autospray.setOnClickListener(new RadioButton.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (!flag){
                    autospray.setChecked(false);
                    Auto=false;
                    flag=true;}//单选按钮未选中
                else {autospray.setChecked(true);
                    Auto=true;
                    flag=false;}//单选按钮选中
            }
        });
        sprayl.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {
                // TODO Auto-generated method stub
                if(sprayl.isChecked())
                    checkL=true;//左侧喷雾选中
                else checkL=false;//左侧喷雾未选中

            }

        });
        sprayr.setOnCheckedChangeListener(new CheckBox.OnCheckedChangeListener()
        {
            @Override
            public void onCheckedChanged(CompoundButton buttonView,
                                         boolean isChecked) {
                if(sprayr.isChecked())
                    checkR=true;//右侧喷雾选中
                else checkR=false;//右侧喷雾未选中
            }

        });
        start.setOnClickListener(new Button.OnClickListener()
        { @Override
        public void onClick(View v) {//喷雾按钮监听
            if (RUN==false )
                RUN = true;
            else
                RUN = false;
            if (RUN ){
                //喷雾按钮按下，参数设置失效
                autospray.setEnabled(false);
                sprayl.setEnabled(false);
                sprayr.setEnabled(false);
                speed.setEnabled(false);
                distance.setEnabled(false);
                ip.setEnabled(false);
                port.setEnabled(false);
                start.setImageDrawable(getResources().getDrawable(R.drawable.stop));
                V = speed.getText().toString();//获取速度当前输入值
                D = distance.getText().toString();//获取当前距离输入值
                sendThread.recHandler.sendEmptyMessage(3);//喷雾标识
            }
            else{
                //停止按钮按下，参数设置使能
                autospray.setEnabled(true);
                sprayl.setEnabled(true);
                sprayr.setEnabled(true);
                speed.setEnabled(true);
                distance.setEnabled(true);
                ip.setEnabled(true);
                port.setEnabled(true);
                start.setImageDrawable(getResources().getDrawable(R.drawable.start));
                sendThread.recHandler.sendEmptyMessage(4);//停止标识
            }
            sendThread.sendHandler.sendEmptyMessage(6);//发送6使得进入数据接收消息循环
        }
        });
        out.setOnClickListener(new Button.OnClickListener()
        { @Override
        public void onClick(View v) {//退出程序
            sendThread.recHandler.sendEmptyMessage(5);//退出标识
            OUT=true;
            onDestroy();//调用onDestroy()释放空间
            System.exit(0);//退出界面
        }
        });


    }
    //显示Toast函数
    public void displayToast(String s)
    {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    //根据子线程传来的消息刷新界面
    Handler myHandler  = new Handler() {//定义一个句柄，负责界面刷新
        public void  handleMessage(Message msg ) {
            super.handleMessage(msg);
            switch(msg.what){
                case 0: {
                    displayToast("连接成功！");
                    //连接按钮失效
                    connect.setEnabled(false);
                    //喷雾按钮使能
                    start.setEnabled(true);
                    break;
                }
                case 1: {
                    displayToast("连接失败！");
                    //连接按钮使能
                    connect.setEnabled(true);
                    break;
                }

                case 0x123: {//若接收到的是更新指示
                    Bundle b = msg.getData();
                    NOZZLE=b.getByteArray("NOZZLE");//获取灯的状态数组
                    //根据喷头开闭情况更新灯的状态
                    if(NOZZLE[0]==1)
                        image4.setImageResource(R.drawable.on);
                    else image4.setImageResource(R.drawable.off);

                    if(NOZZLE[1]==1)
                        image3.setImageResource(R.drawable.on);
                    else image3.setImageResource(R.drawable.off);
                    if(NOZZLE[2]==1)
                        image2.setImageResource(R.drawable.on);
                    else image2.setImageResource(R.drawable.off);
                    if(NOZZLE[3]==1)
                        image1.setImageResource(R.drawable.on);
                    else image1.setImageResource(R.drawable.off);
                    if(NOZZLE[4]==1)
                        image5.setImageResource(R.drawable.on);
                    else image5.setImageResource(R.drawable.off);
                    if(NOZZLE[5]==1)
                        image6.setImageResource(R.drawable.on);
                    else image6.setImageResource(R.drawable.off);
                    if(NOZZLE[6]==1)
                        image7.setImageResource(R.drawable.on);
                    else image7.setImageResource(R.drawable.off);
                    if(NOZZLE[7]==1)
                        image8.setImageResource(R.drawable.on);
                    else image8.setImageResource(R.drawable.off);
                    break;
                }
                default:
                    break;

            }}

    };

    //释放资源
    @Override
    public void onDestroy(){
        super.onDestroy();
        if (OUT){  try
        {   if(ClientThread.s!=null) {
            ClientThread.s.shutdownInput();//关闭Socket的输入流
            ClientThread.s.shutdownOutput();//关闭Socket的输出流
            ClientThread.s.close();//关闭套接字
            ClientThread.s=null;
        }
        }
        catch (IOException e)
        {}
            ClientThread.recvThread.interrupt();//关闭数据接收线程
            myHandler.removeCallbacksAndMessages(null);//清空消息队列，防止Handler强引用导致内存泄漏
        }
    }
}
